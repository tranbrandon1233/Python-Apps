# Name: Calculation Project
# Purpose: Find total and average of 3 numbers provided by the user
# Programmer: Brandon Tran

num1 = float(input("Please enter the first number: "))
num2 = float(input("Please enter the second number: "))
num3 = float(input("Please enter the third number: "))

print("Total of those three numbers is:", num1+num2+num3)
print("Average of those three numbers is:", (num1+num2+num3)/3)
print("Thank you for participating!")