# Name: Sum Calculator
# Purpose: Reads 6 integers and then finds and prints the sum of the even and odd integers
# Programmer: Brandon Tran

evenSum = 0 #Initialize variables
oddSum = 0
x = 0

while True:
    try:
        print("Please enter 6 integers:") #User prompt
        num1 = input(">") #User inputs
        num2 = input(">")
        num3 = input(">")
        num4 = input(">")
        num5 = input(">")
        num6 = input(">")

        listOfNums = [int(num1),int(num2),int(num3),int(num4),int(num5),int(num6)] #Create a list of numbers

        while x <= 5: #Repeat for all numbers in the list
            if listOfNums[x]%2 == 0: #Check if number is even
                evenSum += listOfNums[x] #If the number is even, add it to the sum of even numbers
            else: #If number is not even,
                oddSum += listOfNums[x] #Add it to the sum of odd numbers
            x += 1 #Add 1 to iteration variable

        print("\n"+"Even sum: ", evenSum) #Print sums
        print("Odd sum: ", oddSum)

        print('\n'+"Do you wish to repeat this program? (y/n)") #Prompt to replay program
        replayInput = input(">")

        if replayInput =="y": #If the user wants to restart the program,
            print('\n') #Line break
            evenSum = 0 #Reset sums
            oddSum = 0
            listOfNums = [] #Clear list
            x = 0 #Reset iteration variable

        else: #If the user wants to end the program,
            print("\n"+"Done!") #Display exit message
            break #Exit loop
    except:
        print('\n'+"Incorrect input!")
        print('\n'+"Do you wish to repeat this program? (y/n)") #Prompt to replay program
        replayInput = input(">")

        if replayInput =="y": #If the user wants to restart the program,
            evenSum = 0 #Reset sums
            oddSum = 0
            listOfNums = [] #Clear list

        else: #If the user wants to end the program,
            print("\n"+"Done!") #Display exit message
            break #Exit loop