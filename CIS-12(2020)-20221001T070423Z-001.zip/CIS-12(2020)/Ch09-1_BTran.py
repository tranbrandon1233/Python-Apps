#Title: File Reader
#Purpose: Take a file name from user and find out occurrences of characters in the file
#Programmer: Brandon Tran
import string
while True: #Loop until break
    try: #Test if file exits and can be opened
        fileName = input("Please enter file name to process: ") #User inputs file name
        fhand = open(fileName) #Open file
        counts = dict() #Create dictionary
        for line in fhand: #For each line in file
            line = line.translate(line.maketrans('','',string.punctuation)) #Remove punctuation
            words = line.split() #Split line into words 
            for word in words: #For each word,
                for letter in word: #For each letter,
                    counts[letter] = counts.get(letter,0) + 1 #Add 1 to dictionary for each appearance of each letter
        print(counts) #Print counts of words
        userRepeat = input('\n'+"Do you want try another file? (y or n) ") #Prompt to repeat 
        if userRepeat.lower() == "y": #If user wants to repeat program,
            continue #Loop again
        else: #If user does not want to repeat program,
            print("Thank you for playing!") #Message to confirm program is closed
            break #Stop loop  
    except: #If file cannot be opened,
        print("File name " + fileName + " does not exist.") #Error message