#Title: Letter Counter
#Purpose: Count the number of messages from each person, print the person with the most commits, and print out top 5 users with email usage
#Programmer: Brandon Tran
while True: #Loop until break
    try:
        counts = {}
        fileName = input("Please enter file name to process: ") #User inputs file name
        fhand = open(fileName) #Open file
        for line in fhand: #For each line in file
            if line.startswith('From'):
                words = line.split()
                email = words[1]
                counts[email] = counts.get(email,0) + 1 #Add 1 to dictionary for each appearance of each email address
        print("Here is a list of top 5 email users:")
        print("====================================")
        emailCount = 0
        for v, k in sorted( [ (v,k) for k,v in counts.items() ], reverse=True):
            if emailCount < 5:
                print(str(v) + "     " + k)
                emailCount += 1
        print("====================================")
        userRepeat = input("Do you want try another file? (y or n): ") #Prompt to repeat 
        if userRepeat.lower() == "y": #If user wants to repeat program,
            continue #Loop again
        else: #If user does not want to repeat program,
            print("Thank you for playing.") #Message to confirm program is closed
            break #Stop loop 
    except:
        print("File", fileName, "doesn't exist.")
        print("Please enter correct file name.")
