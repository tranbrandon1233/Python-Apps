# Name: Hourly Rate Project with Functions
# Purpose: Find the pay for the week using functions.
# Programmer: Brandon Tran

hoursWorked = input("Please enter number of hours worked for this week: ") #User inputs hours worked
hourlyRate = input("What is hourly rate? ") #User inputs hourly rate

try:
    int(hoursWorked)  #Check if user input is a number
    int(hoursWorked) < 0 == true #Check if user input is greater than 0
    try: 
        int(hourlyRate)  #Check if user input is a number
        int(hourlyRate) < 0 == True #Check if user input is greater than 0
        
        def calPay(hoursWorked,hourlyRate):
            if int(hourlyRate) >= 0: #Check if user input is greater than 0; if it is,
                if int(hoursWorked) >= 0: #Check if user input is greater than 0; if it is,
                    if int(hoursWorked) > 40 and int(hoursWorked) <= 60: #Check to see if hours worked is between 40-60 hours
                        overtimePay = 1.5* int(hourlyRate)*(int(hoursWorked)-40) #Calculate overtime pay
                        payAmount = str((int(hoursWorked)-(int(hoursWorked)-40))*int(hourlyRate)+overtimePay) #Assign pay amount

                    elif int(hoursWorked) > 60: #Check to see if hours worked is over 60 hours
                        overtimePay1 = 1.5* int(hourlyRate)*((int(hoursWorked))-(int(hoursWorked)-20)) #Calculate overtime pay for 40-60 hours
                        overtimePay2 = 2* int(hourlyRate)*(int(hoursWorked)-60) #Calculate overtime pay for over 60 hours
                        payAmount = str((((int(hoursWorked)-(int(hoursWorked)-40)))*int(hourlyRate)+overtimePay1+overtimePay2)) #Assign pay amount

                    else:
                        payAmount = str(int(hoursWorked)*int(hourlyRate)) #Assign pay amount
                    return payAmount #Return final value
            
        print("Your pay amount is: " + calPay(hoursWorked,hourlyRate)) #Print final value


    except:
        print("You entered wrong rate information.") #Output error message
except:
    print("You entered wrong information for hours.") #Output error message