# Name: Sum Calculator
# Purpose:  Use "for" loop find the sum of odd numbers, 
#   sum of even numbers, largest number, and smallest number in a listOfNums.
# Programmer: Brandon Tran

evenSum = 0 #Initialize variables for the sums
oddSum = 0

for eachNum in [3,8,5,1,4,9,2,10,7]: #Check each number in listOfNums
    if eachNum%2 == 0: #Check if the number is even
        evenSum += eachNum #If it is even, add this number to the sum of even numbers
    else: #Check if the number is odd
        oddSum += eachNum #If it is odd, add this number to the sum of odd numbers
print("Sum of even numbers is:", evenSum) #Print sums
print("Sum of odd numbers is:", oddSum)

maxNum = -2 #Assign largest number as -2 temporarily
for eachNum in [3,8,5,1,4,9,2,10,7]: #Use for loop to check each number
    if maxNum < eachNum: #Check if second number in the listOfNums is larger
        maxNum = eachNum #If the number is larger, change the largest number to that number
print('Largest number in the listOfNums is:',maxNum) #Print number

minNum = 999 #Assign smallest number as 999 temporarily
for eachNum in [3,8,5,1,4,9,2,10,7]: #Use for loop to check each number
    if minNum > eachNum: #Check if second number in the listOfNums is smaller
        minNum = eachNum #If the number is smaller, change the smallest number to that number
print('Smallest number in the listOfNums is:',minNum) #Print number