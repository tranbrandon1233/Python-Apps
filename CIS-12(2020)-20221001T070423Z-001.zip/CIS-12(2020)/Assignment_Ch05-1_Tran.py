# Name: Hourly Rate Project with Functions and Loops
# Purpose: Find the pay for the week using functions and loops.
# Programmer: Brandon Tran

repeatValue = 1 # For first run of code
hoursWorked = 0 #Placeholder value for variable

def calPay(hoursWorked,hourlyRate):
    if int(hourlyRate) >= 0: #Check if user input is greater than 0; if it is,
        if int(hoursWorked) >= 0: #Check if user input is greater than 0; if it is,
            if int(hoursWorked) > 40 and int(hoursWorked) <= 60: #Check to see if hours worked is between 40-60 hours
                overtimePay = 1.5* int(hourlyRate)*(int(hoursWorked)-40) #Calculate overtime pay
                payAmount = str((int(hoursWorked)-(int(hoursWorked)-40))*int(hourlyRate)+overtimePay) #Assign pay amount

            elif int(hoursWorked) > 60: #Check to see if hours worked is over 60 hours
                overtimePay1 = 1.5* int(hourlyRate)*((int(hoursWorked))-(int(hoursWorked)-20)) #Calculate overtime pay for 40-60 hours
                overtimePay2 = 2* int(hourlyRate)*(int(hoursWorked)-60) #Calculate overtime pay for over 60 hours
                payAmount = str((((int(hoursWorked)-(int(hoursWorked)-40)))*int(hourlyRate)+overtimePay1+overtimePay2)) #Assign pay amount

            else:
                payAmount = float(int(hoursWorked)*int(hourlyRate)) #Assign pay amount
            return payAmount #Return final value

while repeatValue == 1: #Sets loop
        try:
            if int(hoursWorked) <= 0: #Checks if first input was already made in a previous run
                hoursWorked = input("Please enter number of hours worked for this week: ") #User inputs hours worked
                int(hoursWorked)  #Check if user input is a number
                int(hoursWorked) < 0 #Check if user input is greater than 0
        except:
            print("You entered wrong information for number of hours.") #Output error message
            hoursWorked = -1 #Placeholder value so prompt for hoursWorked will run again
        if int(hoursWorked) >= 0:  #Checks if a valid first input was already made in a previous run
            try: 
                hourlyRate = input("What is hourly rate? ") #User inputs hourly rate
                int(hourlyRate)  #Check if user input is a number
                int(hourlyRate) < 0 == True #Check if user input is greater than 0
                
                calPay(hoursWorked,hourlyRate)

                print("Your pay for the week is: $" + str(calPay(hoursWorked,hourlyRate))) #Print final value
                userRepeat = input('\n'+"Do you want another pay calculation? (y or n) ") #Prompt to repeat 
                if userRepeat.lower() == "y": #If user wants to repeat program,
                    hoursWorked = 0 #Reset hoursWorked
                    repeatValue = 1 #Ensures loop is repeated
                elif userRepeat.lower() == "n": #If user does not want to repeat program,
                    print("Good bye!") #Message to confirm program is closed
                    repeatValue = 0 #Stops loop
            except:
                print("You entered improper information for the rate.") #Output error message
                hourlyRate = 0  #Placeholder value so prompt for hoursWorked will run again