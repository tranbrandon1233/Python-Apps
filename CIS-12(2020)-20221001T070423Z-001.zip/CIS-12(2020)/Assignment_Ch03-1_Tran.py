# Name: Hourly Rate Project
# Purpose: Find the pay for the week
# Programmer: Brandon Tran

hoursWorked = input("Please enter number of hours worked for this week: ") #User inputs hours worked
hourlyRate = input("What is hourly rate? ") #User inputs hourly rate

try:
    float(hoursWorked)  #Check if user input is a number
    float(hoursWorked) < 0 == true #Check if user input is greater than 0
    try: 
        float(hourlyRate)  #Check if user input is a number
        float(hourlyRate) < 0 == true #Check if user input is greater than 0
        if float(hourlyRate) >= 0: #Check if user input is greater than 0; if it is,
            if float(hoursWorked) >= 0: #Check if user input is greater than 0; if it is,
                if float(hoursWorked) > 40 and float(hoursWorked) <= 60: #Check to see if hours worked is between 40-60 hours
                    overtimePay = 1.5* float(hourlyRate)*(float(hoursWorked)-40) #Calculate overtime pay
                    payAmount = str((float(hoursWorked)-(float(hoursWorked)-40))*float(hourlyRate)+overtimePay) #Assign pay amount

                elif float(hoursWorked) > 60:  #Check to see if hours worked is over 60 hours
                    overtimePay = 2* float(hourlyRate)*(float(hoursWorked)-60) #Calculate overtime pay
                    payAmount = str((((float(hoursWorked)-(float(hoursWorked)-60)))*float(hourlyRate)+overtimePay)) #Assign pay amount
                else:
                    payAmount = str(float(hoursWorked)*float(hourlyRate)) #Assign pay amount
        print("Your pay amount is: " + payAmount) #Print final value
    except:
        print("You entered wrong rate information.") #Output error message
except:
    print("You entered wrong information for hours.") #Output error message