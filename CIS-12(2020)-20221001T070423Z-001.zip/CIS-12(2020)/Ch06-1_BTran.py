#Name: Ch06-1_BTran
#Purpose: Take a string as an input and using slice and find function 
#         to extract a string after a colon. Then, convert it to 
#         floating point number and add 2.0 to it.  
#Programmer: Brandon Tran
while True: #Loop code
    try: #Catch errors
        userInput = input("Enter a string with a colon and a number after it.: ") #Collect user input

        colonIndex = userInput.find(":") #Find the colon in the string

        print("Extracted a number from given string and added 2.0 to it:",float(userInput[colonIndex+1:])+2.0) #Find the part of the input after the colon, convert it to a floating point number, add 2.0, and print in console

        repeatInput = input('\n'+"Would you like to try again? (y or n): ") #Ask to repeat program

        if repeatInput.lower() == "y": #If yes,
            continue #Loop program
        else: #If not,
            print("Goodbye.") #Termination message
            break #Exit loop
    except: #If there is an error,
        print("Incorect input. Please try again."+'\n') #Alert user of error