#Title: Word Counter
#Purpose: Take a file name from user and find out occurrences of words in the file.  
#Programmer: Brandon Tran
import string
while True: #Loop until break
    try:
        fileName = input("Please enter file name to process: ") #User inputs file name
        fhand = open(fileName) #Open file
        counts = dict() #Create dictionary
        wordCount = 0 #Keep track of number of words
        for line in fhand: #For each line in file
            line = line.translate(line.maketrans('','',"!#$%&()*+,-./:;<=>?@[\]^_`{|}~")) #Remove punctuation EXCEPT for apostrophe
            words = line.split() #Split line into words 
            for word in words: #For each word,
                word = word.lower() #Convert each word to be lowercase
                counts[word] = counts.get(word,0) + 1 #Add 1 to dictionary for each appearance of each word
        print("Words and frequency in the file " + fileName + " sorted alphabetically")
        for key in sorted(counts.keys()): #For each key in alphabetized dictionary based on keys,
            print(key, counts[key]) #Print each key and the corresponding count
            wordCount += 1
        print("\nThere are", wordCount, "different words in this file.") #Print word count
        userRepeat = input('\n'+"Do you want try another file? (y or n): ") #Prompt to repeat 
        if userRepeat.lower() == "y": #If user wants to repeat program,
            continue #Loop again
        else: #If user does not want to repeat program,
            print("Thank you for playing.") #Message to confirm program is closed
            break #Stop loop  
    except:
        print("File name" + fileName + " cannot be found") #Error message