# Name: Sorting Integers Project With Functions
# Purpose: Sort int(a) list of integers int(b) y ascending order using functions
# Programmer: Brandon Tran

a=input("Please enter the first integer: ") #input first number

b=input("Please enter the second integer: ") #input second number

c=input("Please enter the third integer: ") #input third number

def sortNumber(a,b,c):
    if int(a) > int(b) and int(a) > int(c) and int(b) > int(c): #Check to see which numbers are larger and sort in ascending order
        firstNum = int(c)
        secondNum = int(b)
        thirdNum = int(a) #Assign in ascending order

    elif int(a) > int(b) and int(a) > int(c) and int(c) >= int(b): #Check to see which numbers are larger and sort in ascending order
        firstNum = int(b)
        secondNum = int(c)
        thirdNum = int(a) #Assign in ascending order

    elif int(b) >= int(a) and int(b) > int(c) and int(a) > int(c): #Check to see which numbers are larger and sort in ascending order
        firstNum = int(c)
        secondNum = int(a)
        thirdNum = int(b) #Assign in ascending order

    elif int(b) > int(a) and int(b) > int(c) and int(c) >= int(a):  #Check to see which numbers are larger and sort in ascending order
        firstNum = int(a)
        secondNum = int(c)
        thirdNum = int(b) #Assign in ascending order

    elif int(c) > int(a) and int(c) > int(b) and int(a) >= int(b): #Check to see which numbers are larger and sort in ascending order
        firstNum = int(b)
        secondNum = int(a)
        thirdNum = int(c) #Assign in ascending order

    elif int(c) > int(a) and int(c) > int(b) and int(b) > int(a):  #Check to see which numbers are larger and sort in ascending order
        firstNum = int(a)
        secondNum = int(b)
        thirdNum = int(c) #Assign in ascending order

    elif int(c) >= int(a) and int(c) > int(b):  #Check to see which numbers are larger and sort in ascending order
        firstNum = int(b)
        secondNum = int(a)
        thirdNum = int(c) #Assign in ascending order

    elif int(c) == int(b) and int(a) == int(c):  #Check to see which numbers are larger and sort in ascending order
        firstNum = int(b)
        secondNum = int(c)
        thirdNum = int(a) #Assign in ascending order
    
    print('\n'+"Input three integer numbers in ascending order:" + '\n'+ str(firstNum), str(secondNum), str(thirdNum)) #Print the output
    
sortNumber(a,b,c) #Run the function