#Name: Substring Project
#Purpose:  Ask user to enter a string with two "!" within it to mark substring.  Then, the program 
#          will output letters (including space(s)) surrounded by "!" in reverse order but not including "!".
#Programmer: Brandon Tran
while True: #Loop code 
    try: #Catch errors
        userInput = input("Enter a string with two '!' surrounding portion of the string: ") #User inputs string

        firstExclamationIndex = userInput.find("!") #Find first exclamation point
        secondExclamationIndex = userInput.find("!",firstExclamationIndex+1)  #Find second exclamation point 

        finalString = userInput[firstExclamationIndex+1:secondExclamationIndex] #Remove part of string after second exclamation point
        reversedFinalString = finalString[::-1] #Reverse final string 

        iterationOfLoop = 0 #Track iteration of loop to index
        lengthOfFinalString = len(reversedFinalString) #Find length of string to find number of times to loop

        for letter in reversedFinalString: #For loop based on each letter of string
            print(reversedFinalString[iterationOfLoop]) #Print each letter in string (which was reversed earlier)
            iterationOfLoop += 1 #Increase index for each loop to print next letter of the string

        repeatInput = input("Do you want to try again? (y/n) ") #Ask to repeat

        if repeatInput.lower() == "y": #If user wants to repeat
            continue #Repeat loop
        else:
            print("Thank you for playing.") #Exit statement
            break #Exit loop
    except: #If there is an error,
        print("Incorect input. Please try again."+'\n') #Alert user of error