# Name: Rock Paper Scissors Project
# Purpose: Play rock paper scissors with 2 players
# Programmer: Brandon Tran

print("Enter [R]ock, [P]aper, or [S]cissor") #Prompt for Player 1
player1Input = input("Player 1: ") #Input from Player 1
print("Enter [R]ock, [P]aper, or [S]cissor") #Prompt for Player 2
player2Input = input("Player 2: ") #Input from Player 2

if player1Input.lower() == "s": #If input from Player 1 is scissors (upper or lower case)
    if player2Input.lower() == "s": #If input from Player 2 is scissors (upper or lower case)
        print("\n"+"Nobody WINS!") #Print result for this scenario
    elif player2Input.lower() == "p": #If input from Player 2 is paper (upper or lower case)
        print("\n"+"Scissors cut paper."+'\n'+'Player 1 WINS!') #Print result for this scenario
    elif player2Input.lower() == "r": #If input from Player 2 is rock (upper or lower case)
        print("\n"+"Rock smashes scissor."+'\n'+'Player 2 WINS!') #Print result for this scenario

elif player1Input.lower() == "p": #If input from Player 1 is paper (upper or lower case)
    if player2Input.lower() == "s":  #If input from Player 2 is scissors (upper or lower case)
        print("\n"+"Scissors cut paper."+'\n'+'Player 2 WINS!') #Print result for this scenario
    elif player2Input.lower() == "p":  #If input from Player 2 is paper (upper or lower case)
        print("\n"+"Nobody WINS!") #Print result for this scenario
    elif player2Input.lower() == "r":  #If input from Player 2 is rock (upper or lower case)
        print("\n"+"Paper covers rock."+'\n'+'Player 1 WINS!') #Print result for this scenario

elif player1Input.lower() == "r": #If input from Player 1 is rock (upper or lower case)
    if player2Input.lower() == "s":  #If input from Player 2 is scissors (upper or lower case)
        print("\n"+"Rock smashes scissor."+'\n'+'Player 1 WINS!') #Print result for this scenario
    elif player2Input.lower() == "p":  #If input from Player 2 is paper (upper or lower case)
        print("\n"+"Paper covers rock."+'\n'+'Player 2 WINS!') #Print result for this scenario
    elif player2Input.lower() == "r":  #If input from Player 2 is rock (upper or lower case)
        print("\n"+"Nobody WINS!") #Print result for this scenario