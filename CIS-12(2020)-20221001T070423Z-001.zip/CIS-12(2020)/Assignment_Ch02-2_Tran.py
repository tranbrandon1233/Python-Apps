# Name: Time Conversion Project
# Purpose: Convert seconds to hours, minutes, and seconds
# Programmer: Brandon Tran

timeElapsed = int(input("Enter the elapsed time in seconds: "))  #User inputs time in seconds

hours = int(timeElapsed//3600) #Convert seconds to nearest number of hours
minutes = int((timeElapsed%3600)//60) #Convert seconds to nearest number of minutes, excluding hours
seconds = int((timeElapsed%3600)%60)%60  #Convert seconds to nearest number of seconds, excluding hours and minutes

print('The elapsed time in seconds =', str(timeElapsed)) 
    #Print time elapsed in seconds (same as user's input)
print('The equivalent time in hours:minutes:seconds =', str(hours) + ':' + str(minutes) + ':' + str(seconds)) 
    #Print time elapsed in hours, minutes and seconds