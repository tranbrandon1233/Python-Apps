# Name: Sorting Integers Project With Functions
# Purpose: Sort integers by ascending order using functions
# Programmer: Brandon Tran

a=input("Please enter the first integer: ") #Input first number

b=input("Please enter the second integer: ") #Input second number

c=input("Please enter the third integer: ") #Input third number

if int(a) > int(b) and int(a) > int(c) and int(b) > int(c): #Check to see which numbers are larger and sort in ascending order
    firstNum = str(c)
    secondNum = str(b)
    thirdNum = str(a) #Assign in ascending order

elif int(a) > int(b) and int(a) > int(c) and int(c) > int(b): #Check to see which numbers are larger and sort in ascending order
    firstNum = str(b)
    secondNum = str(c)
    thirdNum = str(a) #Assign in ascending order

elif int(b) > int(a) and int(b) > int(c) and int(a) > int(c): #Check to see which numbers are larger and sort in ascending order
    firstNum = str(c)
    secondNum = str(a)
    thirdNum = str(b) #Assign in ascending order

elif int(b) > int(a) and int(b) > int(c) and int(c) > int(a):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(a)
    secondNum = str(c)
    thirdNum = str(b) #Assign in ascending order

elif int(c) > int(a) and int(c) > int(b) and int(a) > int(b): #Check to see which numbers are larger and sort in ascending order
    firstNum = str(b)
    secondNum = str(a)
    thirdNum = str(c) #Assign in ascending order

elif int(c) > int(a) and int(c) > int(b) and int(b) > int(a):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(a)
    secondNum = str(b)
    thirdNum = str(c) #Assign in ascending order

elif int(c) == int(a) and int(b) > int(c):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(a)
    secondNum = str(c)
    thirdNum = str(b) #Assign in ascending order

elif int(c) == int(a) and int(c) > int(b):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(b)
    secondNum = str(a)
    thirdNum = str(c) #Assign in ascending order

elif int(b) == int(a) and int(b) > int(c):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(c)
    secondNum = str(a)
    thirdNum = str(b) #Assign in ascending order

elif int(b) == int(a) and int(c) > int(b):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(b)
    secondNum = str(a)
    thirdNum = str(c) #Assign in ascending order

elif int(c) == int(b) and int(a) > int(c):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(b)
    secondNum = str(c)
    thirdNum = str(a) #Assign in ascending order

elif int(c) == int(b) and int(c) > int(a):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(a)
    secondNum = str(c)
    thirdNum = str(b) #Assign in ascending order

elif int(c) == int(b) and int(a) == int(c):  #Check to see which numbers are larger and sort in ascending order
    firstNum = str(b)
    secondNum = str(c)
    thirdNum = str(a) #Assign in ascending order

print('\n'+"Input three integer numbers in ascending order:" + '\n'+ firstNum, secondNum, thirdNum) #Print output