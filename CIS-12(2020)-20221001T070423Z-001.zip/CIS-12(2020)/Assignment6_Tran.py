#Name: PDF Extractor
#Programmer: Brandon Tran
#Purpose: Extract a PDF 

from PyPDF2 import PdfFileReader, PdfFileWriter #Import libraries
from pathlib import Path

pdfName = input("Please enter a file name: ") #Input file name
pdf = PdfFileReader(pdfName) #Create the PdfFileReader instance
pdf_writer = PdfFileWriter() #Create a PdfFileWriter instance
startPg = int(input("Please enter the beginning page number to extract: ")) #User input for start page
endPg = int(input("Please enter the ending page number to extract: ")) #Ask for ending page
fileProcessed = True #Create a boolean to control while loop
while(fileProcessed): #Loop indefinitely
    if(startPg <= endPg and endPg <= pdf.getNumPages() and startPg <= pdf.getNumPages() and type(startPg) == int and type(endPg) == int): #If pages are integers, not out of index, and the start page is less than or = to the ending page,
        outputFile = input("Please enter output file name: ")
        for n in range(startPg-1, endPg): #For each page,
            page = pdf.getPage(n) #Get each page in the input PDF
            pdf_writer.addPage(page) #Add it to the writer
            with Path(outputFile).open(mode="wb") as output_file: #Create a new PDF
                pdf_writer.write(output_file) 
        break #Break the loop
    elif (startPg > endPg or type(startPg) != int or type(endPg) != int): #If start page is higher than the ending page
        print("Your beginning and ending page numbers are not correct.") #Error message
        startPg = int(input("Please enter the beginning page number to extract: ")) #Input pages again
        endPg = int(input("Please enter the ending page number to extract: "))
    else: #In all other cases,
        print("Your ending index is out of range, please enter correct ending page.") #Error message
        startPg = int(input("Please enter the beginning page number to extract: ")) #Input pages again
        endPg = int(input("Please enter the ending page number to extract: "))

