# Name: Pay Calculator Project
# Purpose: FInd the pay based on hours worked and hourly rate
# Programmer: Brandon Tran

hoursWorked = input('Enter number of hours worked: ') #User inputs hours worked
hourlyRate = input("Enter hourly rate: ") #User inputs hourly rate

if float(hoursWorked) > 40 and float(hoursWorked) <= 60: #Check to see if hours worked is between 40-60 hours
    overtimePay = 1.5* float(hourlyRate)*(float(hoursWorked)-40) #Calculate overtime pay
    print("\n" + "Your pay amount is: " + str((float(hoursWorked)-(float(hoursWorked)-40))*float(hourlyRate)+overtimePay)) #Print total pay amount 

elif float(hoursWorked) > 60:
    overtimePay = 2* float(hourlyRate)*(float(hoursWorked)-60)
    print("\n" + "Your pay amount is: " + str((((float(hoursWorked)-(float(hoursWorked)-60)))*float(hourlyRate)+overtimePay))) #Print total pay amount 

else:
    print("\n" + "Your pay amount is: " + str(float(hoursWorked)*float(hourlyRate))) #Print total pay amount 



