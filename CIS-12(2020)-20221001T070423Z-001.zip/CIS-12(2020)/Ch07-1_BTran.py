#Title: File Reader Project
#Purpose: Take a file name from user and find out following information and display it:
#           Number of lines, number of vowels, number of consonants, and number of numerical characters
#Programmer: Brandon Tran
while True: #Loop while true
    try:
        lineCount = 0 #Initialize variables
        vowelCount = 0
        consonantCount = 0
        numCount = 0
        fname = input("Please enter file name: ") #Input file directory
        fhand = open(fname) #Open file
        for line in fhand: #For each line in file,
            lineCount = lineCount + 1 #Add to total line count
            for char in line:
                if  char in 'aeiouAEIOU': #Check if character is a vowel
                    vowelCount += 1 #Add to total vowel count
                elif char in 'qwrtypsdfghjklmnbvcxzQWRTYPSDFGHJKLMNBVCXZ': #Check if character is a consonant
                    consonantCount += 1 #Add to total consonant count
                elif char in '1234567890': #Check if character is a number
                    numCount += 1 #Add to total number count
        print("File " + fname + " has " + str(lineCount) +" lines") #Print information
        print("File " + fname + " has " + str(vowelCount) + " vowels") #Print information
        print("File " + fname + " has " + str(consonantCount) + " consonants") #Print information
        print("File " + fname + " has " + str(numCount) + " numerical characters") #Print information

        userRepeat = input('\n'+"Do you want try it again? (y or n) ") #Prompt to repeat 
        if userRepeat.lower() == "y": #If user wants to repeat program,
            continue #Loop again
        else: #If user does not want to repeat program,
            print("Thanks for playing!") #Message to confirm program is closed
            break #Stop loop  
    except:
        print('File not found. Please enter correct file name.\n') #Error message