# Name: Welcome Project
# Purpose: Welcome user to project.
# Programmer: Brandon Tran

name = input("What is your name? ") #User inputs name
print("Welcome", name) #Output welcomes user