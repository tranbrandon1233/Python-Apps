#Name: Brandon Tran
#Purpose: Take a file name from user, access the file, 
#             and find out all the words in the file and list them in alphabetical order.
#Programmer: Brandon Tran
while True: #Loop while true
    try:
        listOfWords = [] #Create an empty array
        wordCount = 0 #Variable to count number of words
        fname = input("Enter file name: ") #Input file directory
        fhand = open(fname) #Open file
        
        for line in fhand: #For each line in a file,
            words = line.split() #Split the line into words
            for elem in words: #For each word in a line,
                if elem.lower() not in listOfWords: #Check if word is already in the array,
                    wordCount += 1 #Count words
                    listOfWords.append(elem.lower()) #Add unique word to array
        print('\n') #Line break (cannot be concatenated with the list)
        print(sorted(listOfWords)) #Print sort list of words
        print('\nFile',fname,'has', wordCount, 'different words') #Print number of words

        userRepeat = input('\n'+"Do you want try it again? (y or n): ") #Prompt to repeat 
        if userRepeat.lower() == "y": #If user wants to repeat program,
            continue #Loop again
        else: #If user does not want to repeat program,
            print("\nThank you for playing.") #Message to confirm program is closed
            break #Stop loop  
    except:
        print('File not found. Please enter correct file name.\n') #Error message