#Name: Midterm Project
#Purpose: Write a Python program which will take a string as an input and output a string without any spaces before and after.
#Programmer: Brandon Tran
while True: #Loop program 
    userInput = input('\n'+"Please enter a string consists of alphanumeric characters: ") #User inputs string
    numberOfNumbers = 0 #Initialize variables
    numberOfLetters = 0
    sumOfDigits = 0

    newString = userInput.strip(' ') #Strip spaces from beginning and end of userInput
    for s in newString: #For each letter in the string without spaces
        if s.isdigit(): #Check if character is a number
            numberOfNumbers += 1 #Add 1 to number of digits in string
            sumOfDigits += int(s) #Add calue of the number to total sum of the digits
        elif s.isalpha(): #Check if character is a letter
            numberOfLetters += 1 #Add 1 to number of letters in string
    print("Your string is " + str(len(newString)) + " long") #Print the information
    print("Your string has " +  str(numberOfLetters) + " alphabets.")
    print("Your string has " +  str(numberOfNumbers )+ " digits.")
    print("Your string digits total is: " + str(sumOfDigits) + '\n')

    replayInput = input("Do you want to try again? (y or n) ") #Ask to repeat
    if replayInput.lower() == 'n': #If user wants to repeat program,
        print('\n'+"Thank you for playing.") #Termination message
        break #Break loop
    else: #If not,
        continue #Repeat the loop