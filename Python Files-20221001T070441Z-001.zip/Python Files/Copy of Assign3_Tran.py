# Name: Assignment 3
# Manipulate arrays.
# Programmer: Brandon Tran

alpha = [] #Create arrays
beta = []
inStock = [[0 for col in range(4)] for row in range(10)]
gamma = [11, 13, 15, 17]
delta = [3, 5, 2, 6, 10, 9, 7, 11, 1, 8]

def setZero(): #Create setZero function
    for x in range (0,20): #loop 20 times
        alpha.append(0) #add a 0 to arrays
        beta.append(0)
    print("Alpha after initialization:")

def inputArray(): #inputArray function
    print("\n\n\nEnter 20 Integers: ") #user prompt
    for x in range (0,20): #loop 20 times
        numInput = input("") #ask for user input
        alpha[x] = numInput #assign user input to alpha
    print("\n\nAlpha after reading 20 numbers:")

def doubleArray(): #doubleArray function
    i = 0 #initialize loacal var to loop through arrays
    print("\n\n\nBeta after a call to doubleArray:")
    for i in range (0, len(beta)): #for the entire size of the beta array
        beta[i] = 2*int(alpha[i]) #assign 2 times the value of each elem in alpha to beta

def copyGamma():
    for i in range (0,10): #for each elem in gamma
        if i == 1:
            inStock[0][i] = gamma[i] #add the corresponding elem from gamma to the first column of inStock
        else:
            for col in range (0,4): #for each column
                inStock[row][col] = 3*int(inStock[row-1][col]) #assign 3 times the value of the num in the previous row to the current index
    print("\n\n\ninStock after a call to copyGamma:")
    for row in range (0,10): #for each row
        if row > 0: #if this is NOT the first loop,
            print('\n') #add a line break
        for col in range (0,4): #for each column,
            print(str(inStock[row][col]) + "\t", end = "") #print the index with spacing and do not add a line break

def copyAlphaBeta():
    m = 0 #initialize vars to iterate through arrays
    n = 0
    for row in range(0,5): #for each of the first 5 rows,
        for col in range (0,4): #for each column,
            inStock[row][col] = alpha[m] #assign each value in alpha to the first half of the inStock array
            m += 1 #add 1 to interate through the alpha array
    for row in range(5,10): #for each of the last 5 rows,
        for col in range (0,4): #for each column,
            inStock[row][col] = beta[n] #assign each value in beta to the second half of the inStock array
            n += 1 #add 1 to interate through the beta array
    print("\n\n\ninStock after a call to copyAlphaBeta:")
    for row in range (0,10): #for each row
        if row > 0: #if this is NOT the first loop,
            print('\n') #add a line break
        for col in range (0,4): #for each column,
            print(str(inStock[row][col]) + "\t", end = "") #print the index with spacing and do not add a line break

def printArray(array):
    for num in range (0,20): #loop 20 times
        print(str(array[num]) + "\t", end = "") #print each elem in the array and add spacing w/o creating a new line
        if num == 9: #after 10 numbers,
            print('\n') #break a line

def setInStock():
    i = 0 #initialize var to iterate through delta array
    print('\n\n\nEnter 10 integers:') #user prompt
    for row in range (0,10): #for each row,
        numInput = input("") #user input
        inStock[row][0] = int(numInput) #assign user input to inStock
    for row in range (0,10): #for each row
        if row > 0: #If the loop has run at least once before,
            i += 1 #Increase index of delta by 1 for each loop
        for col in range (1,4): #for each column after the first one
            inStock[row][col] = 2*int(inStock[row][col-1]) - delta[i] #assign each index to be twice the value of the number in the previous column subtracted by the corresponding value in delta
    print("\n\ninStock after a call to setInStock:")
    for row in range (0,10): #for each row
        if row > 0: #if this is NOT the first loop,
            print('\n') #add a line break
        for col in range (0,4): #for each column,
            print(str(inStock[row][col]) + "\t", end = "") #print the index with spacing and do not add a line 

#run all functions as needed
setZero()
printArray(alpha)
inputArray()
printArray(alpha)
doubleArray()
printArray(beta)
copyGamma()
copyAlphaBeta()
setInStock()