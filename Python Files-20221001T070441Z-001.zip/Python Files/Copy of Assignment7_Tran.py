#Name: Brandon Tran
#Date: 12/10/20
#Purpose: Merge files together

from pathlib import Path #import libraries
from PyPDF2 import PdfFileMerger

PDF_path = (Path.home()/".."/".."/"Jason"/"PCC"/"Python"/"Adv Python"/"PDFfiles"/"Merge") #Create file path
PLearn = list(PDF_path.glob("*.pdf")) #Create list of files
PLearn.sort() #Sort the files
pdf_M = PdfFileMerger() #Create merger instance
for path in PLearn: #Fir each file in the list
	pdf_M.append(str(path)) #Append it to the merger
with Path(PDF_path/"Merge.pdf").open(mode='wb') as outpf: #cCreate the file as Merge.pdf
	pdf_M.write(outpf) 

