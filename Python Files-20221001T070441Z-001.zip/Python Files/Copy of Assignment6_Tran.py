#Name: PDF Checker
#Programmer: Brandon Tran
#Purpose: Check a PDF 
#NOTE: The assignment did not ask for user input for the file path, so I am assuming the PDF is in the same folder.

from pyPdf import PdfFileReader

while(True):
    pdfName = input("Please enter a file name: ")
    pdf = PdfFileReader(pdfName)
    pdf_writer = PdfFileWriter()
    pgCount = input("Please enter the beginning page number to extract: ")

    try:
        for n in range(1, int(pgCount)):
            page = input_pdf.getPage(pgCount)
            pdf_writer.addPage(page)
        with Path("NewPDF.pdf").open(mode="wb") as output_file:
            pdf_writer.write(output_file)
    except:
        print("Your beginning and ending page numbers are not correct.")