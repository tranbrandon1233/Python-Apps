#Name: File Editor
#Purpose: Create and write a text document.
#Programmer: Brandon Tran

import re,os #import library

dir = os.getcwd()

def fileCheck(): #Create function to check name of file
    while (True): #Loop until it is correct
        check1 = False #Check to see if condition has been satisfied
        check2 = False
        check3 = True #True by default but will change if condition fails
        fileName = input("Please enter a filename: ") #User input
        if re.search('\A[a-zA-Z_]',fileName) == None: #Check to see if first character is a letter or underscore
            print("Filename only can start with Alphabets or '_'.")
            continue #If not, print error message and loop again
        else: #If so,
            check1 = True #Condition is met
        if re.search("\.", fileName) == None: #If there is NOT a period in the file name
            print('File name needs to have an extension.') #Error message
            continue #Loop again
        else: #If there is one
            check2 = True #Condition is met
        for x in re.findall('[\W]', fileName): #For each non-alphanumeric character
            if str(x) != '.' and str(x) != "": #If the char is not a period or blank
                print('Filename can contain only Alphabets, digits and "_".') #Error message
                check3 = False #Condition has NOT been met
                break #Break from for loop to return to while loop
        if check1 and check2 and check3 == True: #If all conditions are met
            return fileName #return file name

def addText(file): #Function to add text to file
    txtFile = open(os.path.join(dir,file),"w") #Create the file
    while(True): #Loop until user is finished
        text = input("Please enter a sentence: ") #User inputs sentence
        txtFile.write(text) #Add text to the file
        response = input("Do you want to add more lines? (Y/N) ") #Ask user if another line needs to be added
        if response.lower() == "y": #If user says yes,
            txtFile.write('\n') #Line break
            continue #Loop again
        else: #If not,
            txtFile.close() #Close and save the file
            break #Break the loop

def printText(file): #Function to print file
    txtFile = open(os.path.join(dir,file), "r+") #Open file to read
    print("\nThis is what's entered into file", file)
    print("============================================")
    print(txtFile.read()) #Print file
    print("============================================")
    txtFile.close() #Close the file

def moreFiles(fileName): #Function to ask if more files should be created
    response = input("Do you want to create another file? (Y/N) ") #User prompt
    if response.lower() == "y": #If so,
        print("Let's create another file.")
        return True #Return true
    else: #If not,
        print("Thank you for playing!")
        return False #Return false

loop = True #Var to control loop
while(loop): #Loop until loop var is false
    fileName = fileCheck() #Run the functions 
    addText(fileName)
    printText(fileName)
    loop = moreFiles(fileName) #Loop wil run until moreFiles() function is false