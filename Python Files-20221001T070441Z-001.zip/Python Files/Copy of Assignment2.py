def checkPrime(n):
    if n == 1: #If n is 1,
        return False #It is not primee

    factors = 0 #Track factors for n
    
    for i in range(1, n+1): #Loop for full quantity of n
        if n % i == 0: #If n is divisible with another number without a remainder,
            factors += 1 #Add one to number of factors
    if factors == 2: #If the number of factors is exactly 2,
        return True #The number is prime
    return False #If not, it is not prime

while True: #Loop indefinitely
    num = int(input("Please enter a number: " )) #user inputs number
    if checkPrime(num) == True: #If the number is prime,
        print(num, "is a prime number.") #Print that the number is prime
    else: #If not,
        print(num, "is not a prime number.") #Print that the number is not prime

    response = input("Do you want to repeat? (Y/N): ") #Ask to repeat
    if response.lower() == "y": #If response is yes,
        print('\n') #Line break
        continue #Repeat loop
    else: #If not,
        print('\n')  #Line break
        print("Thank you for playing.") #Exit message
        break #Break loop
