#Name: Calculator
#Programmer: Brandon Tran
#Purpose: Create a calculator

import tkinter as tk #Import library

window = tk.Tk() ##Create window
window.title("Calculator") #Create title
window.geometry("423x281") #Set size

btn1 = lambda: label.config(text=label['text']+"1") #Lambda functions to set text when corresponding button is pushed
btn2 = lambda: label.config(text=label['text']+"2")
btn3 = lambda: label.config(text=label['text']+"3")
btn4 = lambda: label.config(text=label['text']+"4")
btn5 = lambda: label.config(text=label['text']+"5")
btn6 = lambda: label.config(text=label['text']+"6")
btn7 = lambda: label.config(text=label['text']+"7")
btn8 = lambda: label.config(text=label['text']+"8")
btn9 = lambda: label.config(text=label['text']+"9")
btnPlus = lambda: label.config(text=label['text']+"+")
btnMinus = lambda: label.config(text=label['text']+"-")
btnMult = lambda: label.config(text=label['text']+"*")
btnSlash = lambda: label.config(text=label['text']+"/")
btn0 = lambda: label.config(text=label['text']+"0")
btnDec = lambda: label.config(text=label['text']+".")
btnClr = lambda: label.config(text="") #Clear text when "Clear" button is pushed
btnEqual = lambda: label.config(text=str(eval(label['text']))) #Calculate answer when "=" btn is pushed

label = tk.Label(window,bg='#FFFFE0', width=55,height=4) #Create label for output
label.place(x=15,y=5) #Place label
button1 = tk.Button(text = "1", width=14, height=2, command = btn1) #Create and place all buttons
button1.place(x=0,y=80)
button2 = tk.Button(text = "2", width=14, height=2, command = btn2)
button2.place(x=105,y=80)
button3 = tk.Button(text = "3", width=14, height=2, command = btn3)
button3.place(x=210,y=80)
button4 = tk.Button(text = "4", width=14, height=2, command = btn4)
button4.place(x=0,y=120)
button5 = tk.Button(text = "5", width=14, height=2, command = btn5)
button5.place(x=105,y=120)
button6 = tk.Button(text = "6", width=14, height=2, command = btn6)
button6.place(x=210,y=120)
button7 = tk.Button(text = "7", width=14, height=2, command = btn7)
button7.place(x=0,y=160)
button8 = tk.Button(text = "8", width=14, height=2, command = btn8)
button8.place(x=105,y=160)
button9 = tk.Button(text = "9", width=14, height=2, command = btn9)
button9.place(x=210,y=160)
buttonDecimal = tk.Button(text = ".", width=14, height=2, command = btnDec)
buttonDecimal.place(x=210,y=200)
button0 = tk.Button(text = "0", width=29, height=2, command = btn0)
button0.place(x=0,y=200)
buttonEqual = tk.Button(text = "=", width=44, height=2, command = btnEqual)
buttonEqual.place(x=0,y=240)
buttonSlash = tk.Button(text = "/", width=14, height=2, command = btnSlash)
buttonSlash.place(x=315,y=200)
buttonPlus = tk.Button(text = "+", width=14, height=2, command = btnPlus)
buttonPlus.place(x=315,y=80)
buttonMultiply = tk.Button(text = "*", width=14, height=2, command = btnMult)
buttonMultiply.place(x=315,y=160)
buttonMinus = tk.Button(text = "-", width=14, height=2, command = btnMinus)
buttonMinus.place(x=315,y=120)
buttonClear = tk.Button(text = "Clear", width=14, height=2, command = btnClr)
buttonClear.place(x=315,y=240)

window.mainloop() #Function needed to start the event controller