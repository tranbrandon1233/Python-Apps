#Name: Brandon Tran
#Date: 12/10/20
#Purpose: Merge files together by page

from pathlib import Path #import libraries
from PyPDF2 import PdfFileMerger

Merged_dir = (Path.home()/".."/".."/"Jason"/"PCC"/"Python"/"Adv Python"/"PDFfiles"/"Merge")
Data1 = (Merged_dir/"pythonlearn_ch8MissingPages.pdf")
Data2 = (Path.home()/"From_pythonlearn_ch8.pdf")
 #Create file paths
 
pdf_M = PdfFileMerger() #Create merger instance

pdf_M.append(str(Data1))
pdf_M.merge(4, str(Data2))  
with Path("MergedFile.pdf").open(mode="wb") as output_file:
	pdf_M.write(output_file)
