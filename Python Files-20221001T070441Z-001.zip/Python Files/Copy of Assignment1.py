def findingLeapYear(year): #function to find if year is a leap year
    if year%4 == 0 and (year%100 != 0 or year%400 == 0): #if the year is divisible by 4, not divisible by 100 OR divisible by 400,
        leapYear = True #it is a leap year
    else: #in any other case,
        leapYear = False # it is not a leap year
    return leapYear #return the boolean

def daysInMonth(leapYear): #function to find number of days in Feburary
    if leapYear == True: #if it is a leap year,
        days = 29 #the number of days is 29
    else: #if not,
        days = 28 #the number of days is 28
    return days #return number of days
    
while True: #Loop indefinitely
    year = int(input("Please enter the 4 digit year: ")) #User input for year and month
    month = int(input("Please enter the month: "))
    leapYear = findingLeapYear(year) #Call functions
    days = daysInMonth(leapYear)
    print("Year", year, "Month", month, "has", days, "days in a month") #Print month and year

    response = input("Do you want to repeat? (Y/N): ") #Ask to repeat
    if response.lower() == "y": #If response is yes,
        print('\n') #Line break
        continue #Repeat loop
    else: #If not,
        print('\n')  #Line break
        print("Thank you for playing!") #Exit message
        break #Break loop